﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestNetCore.Models.API
{
    public class AccuWheatherViewModel : BaseViewModel
    {
        public string City { get; set; }
    }
}
