﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestNetCore.Models.API
{
    public class AtmPB
    {
        public string FullAdressRu { get; set; }
        public string PlaceRu { get; set; }
        public string CityRu { get; set; }
    }
}
