﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestNetCore.Models.WidgetsViewModels
{
    public class IsFreeRoom
    {
        public int Number { get; set; }
        public bool IsFree { get; set; }
    }
}
