﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TestNetCore.Models;

namespace TestNetCore.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<ClaimsDataUser> ClaimsDataUsers { get; set; }
        //public DbSet<TableIncome> TableIncomes { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            //Database.EnsureCreated();
        }
    }
}
