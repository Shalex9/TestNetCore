﻿function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) ===' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(cname, cvalue, expdays) {
    var d = new Date();
    d.setTime(d.getTime() + (expdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

var lang;
function SetLanguage(lang) {
    //var oldLanguage = getCookie('language');
    setCookie("language", lang, 30);

    // AJAX for Translate
    //function ajaxTranslate() {
    //    var myData = { language: lang };
    //    $.ajax({
    //        url: "/PersonalCabinet/AjaxTranslate",
    //        type: "POST",
    //        data: myData,
    //        success: function (data) {
    //            $("#optcurrentDay span").text(data.statCurrentDay);
    //            $("#optcurrentWeek span").text(data.statCurrentWeek);
    //            $("#optcurrentMonth span").text(data.statCurrentMonth);
    //            $("#optcurrentYear span").text(data.statCurrentYear);
    //            $("#optlast24hours span").text(data.stat24Hours);
    //            $("#optlast7days span").text(data.stat7Days);
    //            $("#optlast30days span").text(data.stat30Days);
    //            $("#optlast12months span").text(data.stat12Months);
    //            $("#optallTime span").text(data.statAllTime);
    //            $("#optselectPeriod span").text(data.statSelectPeriod);
    //            $("#StateSelect_hidden").val(data.lastState);

    //            // for Selectbox - selected item to display in tag <p>
    //            $("#SelectedCategory [value='card']").text(data.categoryQuestCard);
    //            $("#SelectedCategory [value='webMoney']").text(data.categoryQuestWebMoney);
    //            $("#SelectedCategory [value='other']").text(data.categoryQuestOther);
    //            $('#SelectedCategory').siblings('p').text($('#SelectedCategory').children('option:selected').text());
    //            $('#titleAnimation').siblings('p').text($('#titleAnimation').children('option:selected').text());
    //            $('#textAnimation').siblings('p').text($('#textAnimation').children('option:selected').text());
    //            $('#typeData').siblings('p').text($('#typeData').children('option:selected').text());
    //            $('#theme').siblings('p').text($('#theme').children('option:selected').text());
    //            $('#newsLang').siblings('p').text($('#newsLang').children('option:selected').text());

    //            function animationTitle() {
    //                $(".title").each(function (idx, titleElement) {
    //                    if (this.title) {
    //                        var c = this.title;
    //                        var x = -10;
    //                        var y = 15;
    //                        $(titleElement).mouseover(function (d) {
    //                            var newTitle = titleElement.title;
    //                            this.title = "";
    //                            $("body").append('<div id="tooltip">' + newTitle + "</div>");
    //                            $("#tooltip").css({
    //                                left: (d.pageX + x) + "px",
    //                                top: (d.pageY + y) + "px",
    //                                fontSize: 14 + "px",
    //                                opacity: "0.9"
    //                            }).show(300);
    //                        }).mouseout(function () {
    //                            this.title = c;
    //                            $("#tooltip").remove();
    //                        }).mousemove(function (d) {
    //                            $("#tooltip").css({
    //                                left: (d.pageX + x) + "px",
    //                                top: (d.pageY + y) + "px"
    //                            });
    //                        });
    //                    }
    //                });
    //            }
    //            animationTitle();
    //            console.log(data);
    //            //для перевода категорий вопросов
    //            var categoryArray = data.listCategoryQuestions;
    //            for (var i = 0; i < categoryArray.length; i++) {
    //                $("#allCategory>li>a").each(function (k, item) {
    //                    if (k === i) {
    //                        if (data.lang === "ru") {
    //                            if (categoryArray[i].value === "card") {
    //                                $(item).text("Проблемы оплаты через Приват24");
    //                            }
    //                            if (categoryArray[i].value === "webMoney") {
    //                                $(item).text("Проблемы оплаты через WebMoney");
    //                            }
    //                            if (categoryArray[i].value === "other") {
    //                                $(item).text("Другие вопросы");
    //                            }
    //                        }
    //                        if (data.lang === "uk") {
    //                            if (categoryArray[i].value === "card") {
    //                                $(item).text("Проблеми оплати через Приват24");
    //                            }
    //                            if (categoryArray[i].value === "webMoney") {
    //                                $(item).text("Проблеми оплати через WebMoney");
    //                            }
    //                            if (categoryArray[i].value === "other") {
    //                                $(item).text("Iншi питання");
    //                            }
    //                        }
    //                    }
    //                });
    //            }

    //            //для перевода новостей(читаем из разных ячеек в БД)
    //            var newsArray = data.allNews;
    //            for (var i = 0; i < newsArray.length; i++) {
    //                $(".news-title").each(function (k, item) {
    //                    if (k === i) {
    //                        if (data.lang === "ru") {
    //                            $(item).text(newsArray[i].titleRus);
    //                        }
    //                        if (data.lang === "uk") {
    //                            $(item).text(newsArray[i].titleUkr);
    //                        }
    //                    }
    //                });
    //                $(".news-text").each(function (k, item) {
    //                    if (k === i) {
    //                        if (data.lang === "ru") {
    //                            $(item).text(newsArray[i].textRus);
    //                        }
    //                        if (data.lang === "uk") {
    //                            $(item).text(newsArray[i].textUkr);
    //                        }
    //                    }
    //                });
    //            }
    //        }
    //    });
    //}
    //ajaxTranslate();

    //if (oldLanguage !== lang) {
    //    window.location.reload();
    //}
   $("#Language").val(lang);
    var mesDay,mesWeek,mesMonth,mesYear,donDay,donWeek,donMonth,donYear,sumDay,sumWeek,sumMonth,sumYear,
        date,timeOfDay,day,month,quantity,sum;

    if (lang === "ru") {
        $("#index").text("Главная");
        $("#api").text("API");
        $("#accuWheather").text("Прогноз погоды");
        $("#privatBank").text("ПриватБанк");
        $("#theMovieDB").text("Поиск фильмов");
        $("#file").text("Работа с файлами");
        $("#downloadFile").text("Загрузка/скачивание");
        $("#crudFile").text("CRUD операции");
        $("#ef").text("EntityFramework");
        $("#hotel").text("Бронь отеля");
        $("#phone").text("Покупка телефона");

        // Media gallery
        $("#mgallery").text("Медиа галерея");
        $("#mydownloads").text("Мои загрузки");
        $("#pictures").text("Изображения");
        $("#pictures1").text("Изображения");
        $("#download, .download").text("Загрузить");
        $("#fileName, .fileName").text("Файл не выбран");
        $("#modal_ok").text("Принять");
        $("#modal_cancel").text("Отмена");

        //  "Оповещение о донате"
        $("#donatNotifId").text("Оповещение о донате");
        $("#textNotif")
            .text(
                "То, за чем Вы пришли на этот сайт. Виджет оповещений о сообщениях можно встроить двумя способами: открыв через браузер или запустив его через ");
        $("#or").text(" или");
        $("#textNotif2")
            .text(
                " с использованием специальной ссылки. Различные руководства по интеграции виджета в трансляцию можно найти в нашем разделе");
        $("#helpN").text("'Помощь'");
        $("#labetUrlAlert").text("Ссылка для OBS, XSplit и Kast:");
        $("#hideN").text("Скрыть");
        $("#showN").text("Показать");
        $("#runAlertBox").text("Запуск бокса");
        $("#runAnimation").text("Запуск анимации");
        $("#searchForDate").text("Поиск по датам");
        $("#alertAnim").text("Анимация запустится в течении трех секунд.");
        $("#animIsRun").text(" Анимация уже запущена. Подождите завершения текущей анимации и повторите запуск.");
        $("#generateLink").text("Генерировать ссылку");
        $("#settings").text("Настройки оповещения");
        $("#main").text("Основные:");
        $("#animOn").text("Включить анимацию:");
        $("#titleAn").attr({
            "title":
                "Если установлено значение «Включить», уведомления будут отображаться как обычно. Если установлено значение «Отключить», уведомления не появятся. Это может быть полезно, если Вы - МЕГА СТРИМЕР, и Вы не хотите, чтобы Вас заливали уведомлениями."
        });
        $("#minpayam").text("Минимальная сумма платежа:");
        $("#dontitle").attr({
            "title":
                "Минимальное пожертвование, о котором будет сообщено в уведомлении. Это полезно, если Вы хотите чтобы уведомления срабатывали только для пожертвований больших объемов. Установка этого значения на 0 приведет к тому, что Вы будете получать абсолютно все уведомления,  независимо от суммы пожертвования."
        });
        $("#bgcolor").text("Цвет фона:");
        $("#bgtitle").attr({
            "title":
                "Этот фоновый цвет предназначен только для предварительного просмотра. Он не будет показан в вашем потоковом программном обеспечении."
        });
        $("#bgcolmes").text("Цвет фона сообщения:");
        $("#bgcoltitle").attr({
            "title":
                "Этот фоновый цвет предназначен только для предварительного просмотра. Он не будет показан в вашем потоковом программном обеспечении."
        });
        $("#opacity").text("Прозрачность фона текста:");
        $("#duration").text("Продолжительность:");
        $("#sec").attr({ "title": "Продолжетельность уведомления в секундах" });
        $("#place").text("Расположение:");
        $("#picture").text("Изображение:");
        $("#animpicture").text("Анимация изображения:");
        $("#pictitle").attr({
            "title":
                "Если установлено значение «Включить», изображения уведомлений будут отображаться как обычно.  Если установлено значение «Отключить», изображения уведомлений появляться не будут. Это может быть полезно, если Вам не интересно наблюдать за анимацией картинок, и Вы хотите видеть только сами уведомления."
        });
        $("#labelChooseImg").text("Выбор изображения:");
        $("#imtitle").attr({
            "title":
                "Здесь Вы можете выбрать изображение из стоковой галереи или загрузить своё. После выбора изображения не забудьте нажать кнопку «Принять»."
        });
        $("#animpicture2").text("Анимация изображения:");
        $("#showtitle").attr({
            "title": "Это анимации, которые используются для отображения и скрытия изображений уведомлений."
        });
        $("#startTriggerAnimation").text("Появление");
        $("#endTriggerAnimation").text("Исчезание");
        $("#magn").text("Увеличение изображения:");
        $("#scaletitle").attr({
            "title":
                "Здесь есть возможность изменить масштаб изображения. По умолчанию стоит 1 - это натуральный размер изображения.Вы можете увеличить его пропорционально в несколько раз."
        });
        $("#titleon").attr({
            "title":
                "Если установлено значение «Включить», звуковой сигнал уведомлений будут проигрываться как обычно.  Если установлено значение «Отключить», звукового сигнала уведомлений не будет. Это может быть полезно, если Вам не интересно слушать или Вам мешают аудио сигналы и Вы хотите видеть только анимацию и текст уведомлений."
        });
        $("#labelChooseMelody").text("Выберите мелодию:");
        $("#titleaudio").attr({
            "title":
                "Здесь Вы можете выбрать аудио сигнал для уведомления из стоковой галереи или загрузить свой. После выбора мелодии не забудьте нажать кнопку «Принять»."
        });
        $("#loud").text("Громкость мелодии:");
        $("#animtext").text("Задержка анимации текста:");
        $("#delaytitle").attr({
            "title":
                "Задержка текста уведомления. Это полезно если Вы хотите немного отложить появления текста,  пока не начнется/закончится анимация уведомления."
        });
        $("#snip").text("Шаблон заглавия:");
        $("#holdertitle").attr({
            "title":
                "Когда появится уведомление о пожертвовании, это будет формат заголовка сообщения. {name} - Имя донатора, {amount}  - Сумма, которая была пожертвована. В стилях заглавия эти теги можно будет выделить другим цветом, однако чтобы вместе с именем и суммой не захватывать выделением лишние слова или символы - всегда отделяйте эти теги пробелами с двух сторон!"
        });
        $("#tag").text("Теги {name} и {amount} - обязательны! Их не следует менять!");
        $("#anmes").text("Анимация сообщения:");
        $("#titleText").attr({
            "title": "Это анимации, которые используются для отображения и скрытия текста уведомлений."
        });
        $("#startTriggerAnimationText").text("Появление");
        $("#animationExampleText").text("Тестовый текст");
        $("#endTriggerAnimationText").text("Исчезание");
        $("#Tlstyle").text("Стиль заглавия:");
        $("#btnStyleTitle").text("Стилизировать заглавие");
        $("#titleheader").attr({ "title": "Используется при выводе имени пользователя и суммы платного сообщения." });
        $("#styletext").text("Стиль сообщения:");
        $("#btnStyleText").text("Стилизировать текст сообщения");
        $("#titletext").attr({ "title": "Используется в тексте сообщений." });
        $("#change").text("Редактор стиля текста заглавия");
        //$("#textHeader").text("Текст заглавия");
        $("#anim").text("Анимация:");
        $("#noneTitle").text("Нет");
        $("#vibeTitle").text("Дрожание");
        $("#bounceTitle").text("Прыжки");
        $("#flipTitle").text("Переворот");
        $("#fontcol").text("Цвет шрифта:");
        $("#highlightColor").text("Цвет имени и суммы:");
        $("#optitle").text("Прозрачность заглавия:");
        $("#size").text("Размер заглавия:");
        $("#dist").text("Расстояние между буквами:");
        $("#distword").text("Расстояние между словами:");
        $("#shad").text("Размер тени:");
        $("#bold").text("Жирный текст:");
        $("#under").text("Подчеркнутый:");
        $("#editor").text("Редактор стиля текста сообщения");
        //$("#textmess").text("Текст сообщения");
        $("#textAnim").text("Анимация текста:");
        $("#noneText").text("Нет");
        $("#vibeText").text("Дрожание");
        $("#bounceText").text("Прыжки");
        $("#flipText").text("Переворот");
        $("#fontColor").text("Цвет шрифта:");
        $("#optext").text("Прозрачность текста:");
        $("#textsize").text("Размер текста:");
        $("#distance").text("Расстояние между буквами:");
        $("#distwords").text("Расстояние между словами:");
        $("#shadsize").text("Размер тени:");
        $("#boldtext").text("Жирный текст:");
        $("#underlined").text("Подчеркнутый:");
        $("#alertSave").text("Ваши настройки успешно сохранены.");
        $("#alertReserved").text("Ваш номер успешно забронирован. Вы получите подтверждение на почтовый ящик.");
        $("#alertEngaged").text("На указанные даты свободных номеров нет. Выберите другие даты");
        $("#chooseRoom").text("Выберите более подходящий Вам номер");
    }


    // УКРАЇНСЬКА
    if (lang === "uk") {
        $("#settingsId").text("Entity Framework");
        $("#statSubMenu1").text("Статистика - Підменю 1");
        $("#statSubMenu2").text("Статистика - Підменю 2");
        $("#statSubMenu3").text("Статистика - Phones");
        $("#settSubMenu1").text("EF - Sort");
        $("#settSubMenu2").text("EF - Filter");
        $("#settSubMenu3").text("EF - Pagination");
        $("#settSubMenu4").text("EF - Sort/Filter/Pagination");
        $("#widgSubMenu1").text("Текстове повідомлення");
        $("#widgSubMenu2").text("Бронювання готелю");
        $("#widgSubMenu3").text("Віджети - Підменю 3");
        $("#helpSubMenu1").text("Допомога - Підменю 1");
        $("#helpSubMenu2").text("Допомога - Підменю 2");
        $("#helpSubMenu3").text("Допомога - Підменю 3");

        // Media gallery
        $("#mgallery").text("Медіа галерея");
        $("#mydownloads").text("Мої завантаження");
        $("#pictures").text("Зображення");
        $("#pictures1").text("Зображення");
        $("#download, .download").text("Завантажити");
        $("#fileName, .fileName").text("Файл не вибраний");
        $("#modal_ok").text("Прийняти");
        $("#modal_cancel").text("Відмінити");

        //  "Сповіщення про донат"
        $("#donatNotifId").text("Сповіщення про донат");
        $("#textNotif").text("Те, за чим Ви прийшли на цей сайт. Віджет сповіщення про повідомлення можна вбудувати двома способами: відкривши через браузер або запустивши його через ");
        $("#or").text(" або");
        $("#textNotif2").text(" скориставшись спеціальним посиланням. Різні керівництва по інтеграції віджета в трансляцію можна знайти в нашому розділі");
        $("#helpN").text("'Допомога'");
        $("#labetUrlAlert").text("Посилання для OBS, XSplit та Kast:");
        $("#hideN").text("Сховати");
        $("#showN").text("Показати");
        $("#runAlertBox").text("Запуск бокса");
        $("#runAnimation").text("Запуск анімації");
        $("#searchForDate").text("Пошук по датам");
        $("#alertAnim").text("Анимація запуститься на протязі трьох секунд.");
        $("#animIsRun").text(" Анимація вже запущена. Почекайте завершення текучої анимації та повторіть запуск.");
        $("#generateLink").text("Генерувати посилання");
        $("#settings").text("Налаштування сповіщення");
        $("#main").text("Основні:");
        $("#animOn").text("Включити анімацію:");
        $("#titleAn").attr({
            "title":
                "Якщо встановлено значення «Включити», повідомлення будуть відображатись як звичайно.Якщо встановлено значення  «Виключити», повідомлення не з'являться. Це може бути корисно якщо Ви - МЕГА СТРІМЕР та не хочете щоб Вас засипали повідомленнями."
        });
        $("#minpayam").text("Мінімальна сума оплати:");
        $("#dontitle").attr({
            "title":
                "Мінімальне пожертвування, про яке буде сповіщено в повідомленні. Це корисно, якщо Ви хочете щоб повідомлення спрацьовували тільки для пожертвувань більших розмірів. Встановка цього значеняя на 0 приведе до того, що Ви будете отримувати абсолютно всі повідомлення,  незалежно від суми пожертвування."
        });
        $("#bgcolor").text("Колір фону:");
        $("#bgtitle").attr({
            "title":
                "Цей фоновий колір вибрано тільки для попереднього перегляду. Він не буде показаний у вашому потоковому програмному забезпеченні."
        });
        $("#bgcolmes").text("Колір фону повідомлення:");
        $("#bgcoltitle").attr({
            "title":
                "Цей фоновий колір вибрано тільки для попереднього перегляду. Він не буде показаний у вашому потоковому програмному забезпеченні."
        });
        $("#opacity").text("Прозорість фону тексту:");
        $("#duration").text("Тривалість:");
        $("#sec").attr({ "title": "Тривалість повідомлення в секундах" });
        $("#place").text("Розміщення:");
        $("#picture").text("Зображення:");
        $("#animpicture").text("Анімація зображення:");
        $("#pictitle").attr({
            "title":
                "Якщо встановлено значення «Включити», повідомлення будуть відображатись як звичайно.Якщо встановлено значення  «Виключити», повідомлення не з'являться. Це може бути корисно якщо Вам не цікаво бачити анимацію та Вы хочете бачити тільки самі повідомлення."
        });
        $("#labelChooseImg").text("Вибір зображення:");
        $("#imtitle").attr({
            "title":
                "Тут Ви можете вибрати зображення зі стокової галереї чи завантажити своє. Після вибору зображення не забудьте натиснути кнопку «Прийняти»."
        });
        $("#animpicture2").text("Анімація зображення:");
        $("#showtitle").attr({ "title": "Це анімації, які використовуються для відображення та приховування зображень повідомлень." });
        $("#startTriggerAnimation").text("З'явлення");
        $("#endTriggerAnimation").text("Зникнення");
        $("#magn").text("Збільшення зображення:");
        $("#scaletitle").attr({ "title": "Тут є можливість змінити масштаб зображення. По замовчуванню стоїть 1 - це натуральний розмір зображення.Ви можете збільшити його у кілька разів." });
        $("#titleon").attr({ "title": "Якщо встановлено значення «Включити», звуковий сигнал повідомлень буде програватись як звичайно.Якщо встановлено значення  «Виключити», звукового сигналу повідомлень не буде. Це може бути корисно, якщо Вам не цікаво слухати або Вам заважають аудіо сигнали та Ви хочете бачити тільки анімацію та текст повідомлень." });
        $("#labelChooseMelody").text("Виберіть мелодію:");
        $("#titleaudio").attr({ "title": "Тут Ви можете вибрати аудіо сигнал для повідомлення зі стокової галереї або завантажити свій. Після выбору мелодії не забудьте натиснути кнопку «Прийняти»." });
        $("#loud").text("Гучність мелодії:");
        $("#animtext").text("Затримка анімації тексту:");
        $("#delaytitle").attr({ "title": "Затримка тексту повідомлення. Це корисно якщо Ви хочете трохи затримати появу тексту,  поки не почнеться/закінчиться анімація повідомлення." });
        $("#snip").text("Шаблон заголовка:");
        $("#holdertitle").attr({
            "title":
                "Коли з'явиться повідомлення про пожертвування, це буде формат заголовка повідомлення. {name} - Ім'я донатора, {amount}  - Сума, яка була пожертвувана. У стилях заголовку ці теги буде можливість виділити іншим кольором, але щоб разом з ім`ям та сумою не виділяти зайві слова чи символи - завжди відокремлюйте ці теги пробілами з двух сторін!"
        });
        $("#tag").text("Теги {name} та {amount} - обов'язкові! Їх не слід змінювати!");
        $("#anmes").text("Анімація повідомлення:");
        $("#titleText").attr({ "title": "Це анімації, які використовуються для відображення та приховування тексту повідомлень." });
        $("#startTriggerAnimationText").text("Поява");
        $("#animationExampleText").text("Тестовий текст");
        $("#endTriggerAnimationText").text("Зникнення");
        $("#Tlstyle").text("Стиль заголовка:");
        $("#btnStyleTitle").text("Стилізувати заголовок");
        $("#titleheader").attr({ "title": "Використовується при виводі імені користувача та суми платного повідомлення." });
        $("#styletext").text("Стиль повідомлення:");
        $("#btnStyleText").text("Стилізувати текст повідомлення");
        $("#titletext").attr({ "title": "Використовується в тексті повідомлень." });
        $("#change").text("Редактор стиля тексту заголовка");
        //$("#textHeader").text("Текст заголовка");
        $("#anim").text("Анімація:");
        $("#noneTitle").text("Немає");
        $("#vibeTitle").text("Тремтіння");
        $("#bounceTitle").text("Стрибки");
        $("#flipTitle").text("Переворот");
        $("#fontcol").text("Колір шрифту:");
        $("#highlightColor").text("Колiр iм`я та суми:");
        $("#optitle").text("Прозорість заголовка:");
        $("#size").text("Розмір заголовка:");
        $("#dist").text("Відстань між буквами:");
        $("#distword").text("Відстань між словами:");
        $("#shad").text("Размір тіні:");
        $("#bold").text("Жирний текст:");
        $("#under").text("Підкреслений:");
        $("#editor").text("Редактор стиля тексту повідомлення");
        //$("#textmess").text("Текст повідомлення");
        $("#textAnim").text("Анімація тексту:");
        $("#noneText").text("Немає");
        $("#vibeText").text("Тремтіння");
        $("#bounceText").text("Стрибки");
        $("#flipText").text("Переворот");
        $("#fontColor").text("Колір шрифту:");

        $("#optext").text("Прозорість тексту:");
        $("#textsize").text("Размір тексту:");
        $("#distance").text("Відстань між буквами:");
        $("#distwords").text("Відстань між словами:");
        $("#shadsize").text("Розмір тіні:");
        $("#boldtext").text("Жирний текст:");
        $("#underlined").text("Підкреслений:");
        $("#alertSave").text("Ваші налаштування успішно збережені.");
        $("#alertReserved").text("Ваш номер успішно заброньован. Ви отримаєте підтвердження на поштову скриньку.");
        $("#alertEngaged").text("На вказані дати вільних номерів немає. Виберіть інші дати");
        $("#chooseRoom").text("Виберіть найбільш зручніший для Вас номер");

    }
    
    return true;
}


