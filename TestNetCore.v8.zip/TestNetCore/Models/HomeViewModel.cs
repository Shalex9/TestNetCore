﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestNetCore.Models
{
    public class HomeViewModel : BaseViewModel
    {
        public string UserEmail { get; set; }
    }
}
